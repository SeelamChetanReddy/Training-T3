import React from 'react'

const Assessments = () => {
  return (
    <div>Assessments</div>
  )
}

export default Assessments