import React from 'react'

const Clasroom = () => {
  return (
    <div>Clasroom</div>
  )
}

export default Clasroom