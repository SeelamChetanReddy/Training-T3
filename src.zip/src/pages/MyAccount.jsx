import React from 'react'

const MyAccount = () => {
  return (
    <div style={{width:"50%",height:"50vh",background:"tomato"}}>MyAccount</div>
  )
}

export default MyAccount