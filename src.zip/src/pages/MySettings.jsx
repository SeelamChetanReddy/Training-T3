import React from 'react'

const MySettings = () => {
  return (
    <div style={{width:"50%",height:"50vh",background:"teal"}}>MySettings</div>
  )
}

export default MySettings